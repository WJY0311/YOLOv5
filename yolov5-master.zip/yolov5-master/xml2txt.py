# -*- coding:utf-8 -*-

import xml.etree.ElementTree as ET
import pickle
import os
import ipdb
from os.path import join


sets = ['train', 'test', 'val']

classes = ['valve']  # 填写类别的名字，与后面data/voc.names相同


# 这个函数的主要功能是把xml文件中的标注格式转换成txt需求的格式，并做归一化处理
def convert(size, box):
    dw = 1. / size[0]
    dh = 1. / size[1]
    # 计算中心坐标，xml文件中使用(左上角坐标，右下角坐标)标定一个框，需要转换为中心坐标，宽、高的形式
    x = (box[0] + box[1]) / 2.0
    y = (box[2] + box[3]) / 2.0
    # 计算宽高
    w = box[1] - box[0]
    h = box[3] - box[2]
    # 所有数据归一化处理
    x = x * dw
    w = w * dw
    y = y * dh
    h = h * dh
    return (x, y, w, h)

# 这个函数是读取xml并进行转换
def convert_annotation(image_id):# 输入值为图片的名字，不带后缀
    in_file = open('../valve/labels/%s.xml' % (image_id))# 这里改成自己的xml标注数据集的路径
    out_file = open('../valve/train/labels/%s.txt' % (image_id), 'w')# 这里改成自己的需要存放txt转换结果的路径
    print(image_id)
    tree = ET.parse(in_file)
    root = tree.getroot()
    size = root.find('size')
    w = int(size.find('width').text)
    h = int(size.find('height').text)

    for obj in root.iter('object'):
        # difficult = obj.find('difficult').text
        difficult = '0'
        cls = obj.find('name').text
        if cls not in classes or int(difficult) == 1:
            continue
        cls_id = classes.index(cls)
        xmlbox = obj.find('bndbox')
        b = (float(xmlbox.find('xmin').text), float(xmlbox.find('xmax').text), float(xmlbox.find('ymin').text),
             float(xmlbox.find('ymax').text))
        bb = convert((w, h), b)
        out_file.write(str(cls_id) + " " + " ".join([str(a) for a in bb]) + '\n')

# 接下来遍历自己的xml文件路径，提取文件名（不带后缀）然后循环调用convert_annotation函数，把文件名输入到此函数中即可
print('hello')
for filename in os.listdir('/home/lt/cook/code/wjy/valve/labels/'):
    name = filename.split('.')[0]
    convert_annotation(name)