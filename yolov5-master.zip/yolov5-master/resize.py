from PIL import Image
import os

def convert2jpg(file,outdir):
    img=Image.open('../valve/train/images/'+ file)
    try:
        new_img=img.resize((640,640),Image.BILINEAR)   
        new_img.save(os.path.join(outdir,os.path.basename(file)))
    except Exception as e:
        print(e)
for files in os.listdir('../valve/train/images/'):
    print(files)
    convert2jpg(files,'../valve/resizeImage/')